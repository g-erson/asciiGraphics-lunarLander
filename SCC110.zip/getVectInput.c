#include "vectorAPI.h"
#include "vectorData.h"

wchar_t getChar()
{
   return getch();
}
